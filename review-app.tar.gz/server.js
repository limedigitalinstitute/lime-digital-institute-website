// Lime Reviews — Simple review picker (zero npm deps)
// Run: node server.js
// Env vars:
//   PORT            (default 3000)
//   ADMIN_PASSWORD  (default lime-admin)

const http = require('http');
const fs   = require('fs');
const path = require('path');

const PORT           = process.env.PORT           || 3000;
const ADMIN_PASSWORD = process.env.ADMIN_PASSWORD || 'lime-admin';
const DATA_FILE      = path.join(__dirname, 'data.json');
const PUBLIC         = path.join(__dirname, 'public');

const GOOGLE_REVIEW_URL = 'https://search.google.com/local/writereview?placeid=ChIJA7lcgRLLWTkRUW5dToBEQ28';

const MIME = {
  '.html': 'text/html',
  '.js':   'text/javascript',
  '.css':  'text/css',
  '.svg':  'image/svg+xml',
  '.json': 'application/json',
  '.png':  'image/png',
};

/* ── persistence ─────────────────────────────────────────────────────────── */
function loadData() {
  try {
    const raw = JSON.parse(fs.readFileSync(DATA_FILE, 'utf8'));
    return {
      reviews: Array.isArray(raw.reviews) ? raw.reviews : [],
      sessions: Array.isArray(raw.sessions) ? raw.sessions : [],
    };
  } catch {
    return { reviews: [], sessions: [] };
  }
}
function saveData(data) {
  fs.writeFileSync(DATA_FILE, JSON.stringify(data, null, 2));
}

/* ── helpers ─────────────────────────────────────────────────────────────── */
const clip   = (s, n) => String(s || '').slice(0, n);
const json   = (res, code, body) => {
  res.writeHead(code, {
    'Content-Type': 'application/json',
    'Access-Control-Allow-Origin': '*',
    'Access-Control-Allow-Headers': 'content-type,x-admin-password',
    'Access-Control-Allow-Methods': 'GET,POST,DELETE,OPTIONS',
  });
  res.end(JSON.stringify(body));
};
const readBody = (req) => new Promise(ok => {
  let b = '';
  req.on('data', c => (b += c));
  req.on('end', () => { try { ok(JSON.parse(b || '{}')); } catch { ok({}); } });
});
const isAdmin = (req) => req.headers['x-admin-password'] === ADMIN_PASSWORD;

/* ── CSV parser (simple, handles quoted fields) ──────────────────────────── */
function parseCSV(text) {
  const lines = text.split(/\r?\n/).filter(l => l.trim());
  const rows = [];
  for (const line of lines) {
    const row = [];
    let inQ = false, field = '';
    for (let i = 0; i < line.length; i++) {
      const c = line[i];
      if (c === '"') {
        if (inQ && line[i+1] === '"') { field += '"'; i++; }
        else inQ = !inQ;
      } else if (c === ',' && !inQ) {
        row.push(field.trim()); field = '';
      } else {
        field += c;
      }
    }
    row.push(field.trim());
    rows.push(row);
  }
  return rows;
}

/* ── CSV export ──────────────────────────────────────────────────────────── */
function sessionsToCSV(sessions) {
  const cols = ['sr','timestamp','reviewId','reviewText','copied','opened'];
  const esc  = v => `"${String(v ?? '').replace(/"/g, '""')}"`;
  return [cols.join(','), ...sessions.map(s =>
    [s.sr, s.timestamp, s.reviewId, s.reviewText, s.copied ? 'Yes' : 'No', s.opened ? 'Yes' : 'No'].map(esc).join(',')
  )].join('\r\n');
}

/* ── router ─────────────────────────────────────────────────────────────── */
http.createServer(async (req, res) => {
  const url = new URL(req.url, `http://localhost:${PORT}`);
  const { pathname } = url;

  // CORS preflight
  if (req.method === 'OPTIONS') {
    res.writeHead(204, {
      'Access-Control-Allow-Origin': '*',
      'Access-Control-Allow-Headers': 'content-type,x-admin-password',
      'Access-Control-Allow-Methods': 'GET,POST,DELETE,OPTIONS',
    });
    return res.end();
  }

  /* ── PUBLIC API (student-facing) ─────────────────────────────────────── */

  // GET /api/reviews — get active, uncollected reviews for students to pick
  if (req.method === 'GET' && pathname === '/api/reviews') {
    const data = loadData();
    const active = data.reviews
      .filter(r => r.active && !r.collected)
      .map(r => ({ id: r.id, text: r.text }));
    return json(res, 200, { reviews: active, googleUrl: GOOGLE_REVIEW_URL });
  }

  // POST /api/pick — student picked a review
  if (req.method === 'POST' && pathname === '/api/pick') {
    const b = await readBody(req);
    const reviewId = Number(b.reviewId);
    const data = loadData();
    const review = data.reviews.find(r => r.id === reviewId);
    if (!review) return json(res, 404, { error: 'Review not found' });

    const sr = data.sessions.length ? data.sessions[data.sessions.length - 1].sr + 1 : 1;
    const session = {
      sr,
      timestamp: new Date().toISOString(),
      reviewId: review.id,
      reviewText: review.text,
      copied: false,
      opened: false,
    };
    data.sessions.push(session);
    saveData(data);
    return json(res, 200, { sr, text: review.text, googleUrl: GOOGLE_REVIEW_URL });
  }

  // POST /api/sessions/:sr/copied|opened — mark copy/open
  const sessionMatch = pathname.match(/^\/api\/sessions\/(\d+)\/(copied|opened)$/);
  if (req.method === 'POST' && sessionMatch) {
    const data = loadData();
    const session = data.sessions.find(s => s.sr === Number(sessionMatch[1]));
    if (!session) return json(res, 404, { error: 'not found' });
    if (sessionMatch[2] === 'copied') session.copied = true;
    else session.opened = true;
    saveData(data);
    return json(res, 200, { ok: true });
  }

  /* ── ADMIN API ─────────────────────────────────────────────────────────── */

  // GET /api/admin/reviews — list all reviews (Sr. No. & Review Content)
  if (req.method === 'GET' && pathname === '/api/admin/reviews') {
    if (!isAdmin(req)) return json(res, 401, { error: 'unauthorized' });
    const data = loadData();
    return json(res, 200, data.reviews);
  }

  // POST /api/admin/reviews — add single review (text only)
  if (req.method === 'POST' && pathname === '/api/admin/reviews') {
    if (!isAdmin(req)) return json(res, 401, { error: 'unauthorized' });
    const b = await readBody(req);
    const text = clip(b.text, 2000).trim();
    if (!text) return json(res, 400, { error: 'empty text' });
    const data = loadData();
    const id = data.reviews.length ? Math.max(...data.reviews.map(r => r.id)) + 1 : 1;
    data.reviews.push({ id, text, active: true, addedAt: new Date().toISOString() });
    saveData(data);
    return json(res, 200, { id });
  }

  // POST /api/admin/reviews/bulk — upload bulk reviews (Sr. No. & Review Content only)
  if (req.method === 'POST' && pathname === '/api/admin/reviews/bulk') {
    if (!isAdmin(req)) return json(res, 401, { error: 'unauthorized' });
    const b = await readBody(req);

    let items = []; // { id, text }

    if (b.format === 'csv' && b.csv) {
      // CSV: Column 0 = Sr. No. (optional if header), Column 1 = Review Content (or single column text)
      const rows = parseCSV(b.csv);
      const start = (rows[0] && /sr|no|serial|review|content/i.test(rows[0][0])) ? 1 : 0;
      for (let i = start; i < rows.length; i++) {
        const row = rows[i];
        if (!row || !row.length) continue;
        const text = (row.length > 1 && row[1].trim().length > 5) ? row[1].trim() : (row[0] || '').trim();
        if (text && text.length > 5) {
          items.push(text);
        }
      }
    } else if (b.texts) {
      items = b.texts.split('\n').map(t => t.trim()).filter(t => t.length > 5);
    }

    if (!items.length) return json(res, 400, { error: 'No valid reviews found' });

    const data = loadData();
    let nextId = data.reviews.length ? Math.max(...data.reviews.map(r => r.id)) + 1 : 1;
    let added = 0;

    const existing = new Set(data.reviews.map(r => r.text.toLowerCase().trim()));
    for (const text of items) {
      if (existing.has(text.toLowerCase().trim())) continue;
      data.reviews.push({
        id: nextId++,
        text: clip(text, 2000),
        active: true,
        addedAt: new Date().toISOString(),
      });
      existing.add(text.toLowerCase().trim());
      added++;
    }

    saveData(data);
    return json(res, 200, { added, total: data.reviews.length });
  }

  // POST /api/admin/reviews/:id/toggle — toggle active/inactive
  const toggleMatch = pathname.match(/^\/api\/admin\/reviews\/(\d+)\/toggle$/);
  if (req.method === 'POST' && toggleMatch) {
    if (!isAdmin(req)) return json(res, 401, { error: 'unauthorized' });
    const data = loadData();
    const review = data.reviews.find(r => r.id === Number(toggleMatch[1]));
    if (!review) return json(res, 404, { error: 'not found' });
    review.active = !review.active;
    saveData(data);
    return json(res, 200, { id: review.id, active: review.active });
  }

  // POST /api/admin/reviews/:id/collect — mark review as collected (removes from student pool)
  const collectMatch = pathname.match(/^\/api\/admin\/reviews\/(\d+)\/collect$/);
  if (req.method === 'POST' && collectMatch) {
    if (!isAdmin(req)) return json(res, 401, { error: 'unauthorized' });
    const data = loadData();
    const review = data.reviews.find(r => r.id === Number(collectMatch[1]));
    if (!review) return json(res, 404, { error: 'not found' });
    review.collected = true;
    review.collectedAt = new Date().toISOString();
    saveData(data);
    return json(res, 200, { id: review.id, collected: true, collectedAt: review.collectedAt });
  }

  // POST /api/admin/reviews/:id/uncollect — restore collected review back to pool
  const uncollectMatch = pathname.match(/^\/api\/admin\/reviews\/(\d+)\/uncollect$/);
  if (req.method === 'POST' && uncollectMatch) {
    if (!isAdmin(req)) return json(res, 401, { error: 'unauthorized' });
    const data = loadData();
    const review = data.reviews.find(r => r.id === Number(uncollectMatch[1]));
    if (!review) return json(res, 404, { error: 'not found' });
    review.collected = false;
    review.collectedAt = null;
    saveData(data);
    return json(res, 200, { id: review.id, collected: false });
  }

  // DELETE /api/admin/reviews/:id — delete a review
  const delMatch = pathname.match(/^\/api\/admin\/reviews\/(\d+)$/);
  if (req.method === 'DELETE' && delMatch) {
    if (!isAdmin(req)) return json(res, 401, { error: 'unauthorized' });
    const data = loadData();
    const idx = data.reviews.findIndex(r => r.id === Number(delMatch[1]));
    if (idx === -1) return json(res, 404, { error: 'not found' });
    data.reviews.splice(idx, 1);
    saveData(data);
    return json(res, 200, { ok: true });
  }

  // GET /api/admin/sessions — list sessions
  if (pathname === '/api/admin/sessions') {
    if (!isAdmin(req)) return json(res, 401, { error: 'unauthorized' });
    const data = loadData();
    return json(res, 200, data.sessions);
  }

  // GET /api/admin/sessions.csv — CSV export
  if (pathname === '/api/admin/sessions.csv') {
    if (!isAdmin(req)) return json(res, 401, { error: 'unauthorized' });
    const data = loadData();
    res.writeHead(200, {
      'Content-Type': 'text/csv',
      'Content-Disposition': 'attachment; filename="lime-reviews-sessions.csv"',
    });
    return res.end(sessionsToCSV(data.sessions));
  }

  // GET /api/admin/stats
  if (pathname === '/api/admin/stats') {
    if (!isAdmin(req)) return json(res, 401, { error: 'unauthorized' });
    const data = loadData();
    const poolReviews = data.reviews.filter(r => !r.collected);
    const collectedReviews = data.reviews.filter(r => r.collected);
    return json(res, 200, {
      totalReviews: data.reviews.length,
      poolCount: poolReviews.length,
      collectedCount: collectedReviews.length,
      activeReviews: poolReviews.filter(r => r.active).length,
      totalPicks: data.sessions.length,
      copied: data.sessions.filter(s => s.copied).length,
      opened: data.sessions.filter(s => s.opened).length,
    });
  }

  /* ── Static files ──────────────────────────────────────────────────────── */
  let file = pathname;
  if (pathname === '/' || /^\/r\/[^/]*$/.test(pathname)) file = '/index.html';
  if (pathname === '/admin') file = '/admin.html';

  const full = path.join(PUBLIC, path.normalize(file));
  if (!full.startsWith(PUBLIC) || !fs.existsSync(full) || fs.statSync(full).isDirectory()) {
    res.writeHead(404); return res.end('Not found');
  }
  res.writeHead(200, { 'Content-Type': MIME[path.extname(full)] || 'application/octet-stream' });
  fs.createReadStream(full).pipe(res);

}).listen(PORT, () => {
  console.log(`\n🍋 Lime Reviews running!`);
  console.log(`   Student URL : http://localhost:${PORT}/r/lime`);
  console.log(`   Admin panel : http://localhost:${PORT}/admin`);
  if (ADMIN_PASSWORD === 'lime-admin')
    console.log(`   ⚠  Default password: "lime-admin"`);
  console.log('');
});
